# Employee Management & Deployment Platform

A **production-ready** Employee Management System built with Spring Boot microservices,
React frontend, Docker, Kubernetes, GitHub Actions CI/CD, and Prometheus + Grafana monitoring.
Deployed on AWS EC2 provisioned with Terraform.

---

## Tech Stack

| Layer        | Technology                        |
|-------------|-----------------------------------|
| Backend     | Java 17, Spring Boot 3.2          |
| Frontend    | React 18, React Router, Axios     |
| Database    | PostgreSQL 15                     |
| Container   | Docker, Docker Compose            |
| Orchestration | Kubernetes (K8s)               |
| CI/CD       | GitHub Actions                    |
| Cloud       | AWS EC2, ECR (via Terraform)      |
| Monitoring  | Prometheus + Grafana              |
| Auth        | JWT (JSON Web Tokens)             |

---

## Architecture

```
 React Frontend (port 3000)
       |
       |----> Employee Service  (port 8081) <---> PostgreSQL (port 5432)
       |----> Department Service (port 8082) <---> PostgreSQL (port 5433)

 Prometheus (port 9090) scrapes metrics from both services
 Grafana    (port 3001) visualizes Prometheus data
```

---

## Quick Start (Local with Docker)

```bash
# 1. Clone the repo
git clone https://github.com/yourusername/emp-devops-platform.git
cd emp-devops-platform

# 2. Copy env file
cp .env.example .env

# 3. Start everything
docker-compose up --build -d

# 4. Access the app
# Frontend:          http://localhost:3000
# Employee API:      http://localhost:8081/api/employees
# Department API:    http://localhost:8082/api/departments
# Prometheus:        http://localhost:9090
# Grafana:           http://localhost:3001  (admin / admin123)
```

### Default Login
```
Username: admin
Password: admin123
```

> To create the admin user, call the register endpoint once:
> POST http://localhost:8081/api/auth/register
> Body: { "username": "admin", "password": "admin123" }

---

## API Endpoints

### Auth (Employee Service)
| Method | URL                       | Description         |
|--------|---------------------------|---------------------|
| POST   | /api/auth/register        | Register user       |
| POST   | /api/auth/login           | Login, get JWT      |

### Employees (Protected - requires Bearer token)
| Method | URL                              | Description              |
|--------|----------------------------------|--------------------------|
| GET    | /api/employees                   | Get all employees        |
| GET    | /api/employees/{id}              | Get employee by ID       |
| POST   | /api/employees                   | Create new employee      |
| PUT    | /api/employees/{id}              | Update employee          |
| DELETE | /api/employees/{id}              | Delete employee          |
| GET    | /api/employees/search?keyword=X  | Search employees         |
| GET    | /api/employees/stats             | Get statistics           |

### Departments
| Method | URL                        | Description           |
|--------|----------------------------|-----------------------|
| GET    | /api/departments           | Get all departments   |
| POST   | /api/departments           | Create department     |
| PUT    | /api/departments/{id}      | Update department     |
| DELETE | /api/departments/{id}      | Delete department     |

---

## AWS Deployment with Terraform

```bash
# Prerequisites: AWS CLI configured, SSH key pair ready

cd terraform

# 1. Initialize Terraform
terraform init

# 2. Preview changes
terraform plan

# 3. Deploy EC2 infrastructure
terraform apply

# Output will show:
# ec2_public_ip = "x.x.x.x"
# app_urls = {
#   frontend = "http://x.x.x.x:3000"
#   ...
# }
```

Terraform provisions:
- VPC with public subnet
- Internet Gateway + Route Table
- Security Group (ports: 22, 3000, 3001, 8081, 8082, 9090)
- EC2 Ubuntu instance (t3.medium)
- User-data script that auto-installs Docker and runs the app

---

## Kubernetes Deployment

```bash
# Prerequisites: kubectl configured, images pushed to ECR

# 1. Create namespace
kubectl apply -f k8s/namespace.yaml

# 2. Create config and secrets
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/secret-template.yaml

# 3. Deploy services
kubectl apply -f k8s/employee-deployment.yaml
kubectl apply -f k8s/department-deployment.yaml
kubectl apply -f k8s/frontend-deployment.yaml

# 4. Check status
kubectl get pods -n emp-platform
kubectl get services -n emp-platform
```

---

## CI/CD Pipeline (GitHub Actions)

The pipeline has **4 stages** that run automatically on every push to `main`:

```
Push to main
    │
    ▼
[1] Test       → Run unit tests (Mockito)
    │
    ▼
[2] Build      → Maven package both services
    │
    ▼
[3] Docker     → Build & push images to AWS ECR
    │
    ▼
[4] Deploy     → SSH into EC2 and run docker-compose up
```

### Required GitHub Secrets
```
AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
AWS_ACCOUNT_ID
EC2_HOST           (EC2 public IP from terraform output)
EC2_SSH_KEY        (private SSH key contents)
```

---

## Monitoring (Prometheus + Grafana)

Both services expose metrics at `/actuator/prometheus`.

Metrics tracked:
- HTTP request rate and response time
- JVM heap memory usage
- CPU usage
- Active database connections
- Application uptime

**Access Grafana:** http://localhost:3001
**Login:** admin / admin123
**Add dashboards:** Import dashboard ID `4701` (JVM Micrometer) from grafana.com

---

## Project Structure

```
emp-devops-platform/
├── services/
│   ├── employee-service/         # Spring Boot - Employee CRUD + JWT Auth
│   │   ├── src/main/java/com/emp/
│   │   │   ├── controller/       # REST endpoints
│   │   │   ├── service/          # Business logic
│   │   │   ├── repository/       # JPA repositories
│   │   │   ├── model/            # JPA entities
│   │   │   ├── security/         # JWT filter & utility
│   │   │   └── config/           # Spring Security config
│   │   └── Dockerfile
│   └── department-service/       # Spring Boot - Department CRUD
│       └── Dockerfile
├── frontend/                     # React 18 Dashboard
│   ├── src/
│   │   ├── pages/                # Dashboard, Employees, Departments, Login
│   │   ├── components/           # Navbar
│   │   └── services/             # Axios API calls
│   └── Dockerfile
├── k8s/                          # Kubernetes manifests
│   ├── namespace.yaml
│   ├── configmap.yaml
│   ├── employee-deployment.yaml
│   ├── department-deployment.yaml
│   └── frontend-deployment.yaml
├── terraform/                    # AWS EC2 infrastructure as code
│   ├── main.tf
│   ├── variables.tf
│   └── outputs.tf
├── monitoring/
│   ├── prometheus/prometheus.yml # Scrape config
│   └── grafana/datasource.yml   # Auto-configured datasource
├── .github/workflows/ci-cd.yml  # GitHub Actions pipeline
├── docker-compose.yml           # Local development
├── .env.example
└── README.md
```

---

## Why This Project (Interview Talking Points)

**"Why 2 services instead of 1?"**
> To demonstrate inter-service communication and show that I understand service separation by domain — employees and departments are separate bounded contexts.

**"Why JWT auth?"**
> JWT is stateless, which is perfect for containerized apps — no session storage needed, scales horizontally with no sticky sessions.

**"Why Terraform for EC2 and not manual setup?"**
> Infrastructure as Code means the environment is reproducible and version-controlled. Anyone can rebuild it from scratch with one command.

**"Why Docker Compose for local and K8s for prod?"**
> Docker Compose is fast for local dev. Kubernetes gives us rolling updates, auto-restart, and scaling for production.
